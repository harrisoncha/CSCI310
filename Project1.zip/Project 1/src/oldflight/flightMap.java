package oldflight;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

public class flightMap {

	public static void initiateSearch(HashMap<String,Integer> map, String routeFrom){
		Queue<Queue<String>> possibleRoutes = new LinkedList<Queue<String>>();
		char leavingFrom = routeFrom.charAt(0);
		
		//find all the places that start at the root destination.
		for(Map.Entry<String, Integer> entry : map.entrySet()) {
			
			HashMap<String, Integer> seenAlready = new HashMap<>();
			Queue<String> tmpSet = new LinkedList<String>();
		
			if(entry.getKey().charAt(0) == leavingFrom) {
				String costString = Integer.toString(entry.getValue());
				tmpSet.add(entry.getKey()+costString);
				for(Map.Entry<String, Integer> entry2 : map.entrySet()) {
					if(!entry2.getKey().equals(entry.getKey())){
						seenAlready.put(entry2.getKey(), map.get(entry2.getKey()));
					}
				}	
				searchFlights(tmpSet, seenAlready, entry.getKey(), entry.getValue(), leavingFrom);
			}
			possibleRoutes.add(tmpSet);
		}			
		outputResults(possibleRoutes, routeFrom);
	}
	
	public static void searchFlights(Queue<String> tmpSet, HashMap<String,Integer> hashmap, String key, int prevCost, char root) {
		char leavingFrom = key.charAt(1);
		
		
		for(Map.Entry<String, Integer> entry : hashmap.entrySet()) {
			HashMap<String, Integer> seenAlreadyFunction = new HashMap<>();
			boolean inSet = false;
			
			if(leavingFrom == entry.getKey().charAt(0) && entry.getKey().charAt(0) != root) {
				inSet = true;
			}
			if(inSet) {
				int totalCost = prevCost + entry.getValue();
				tmpSet.add(entry.getKey()+totalCost);
				for(Map.Entry<String, Integer> entry2 : hashmap.entrySet()) {
					if(!entry2.getKey().equals(entry.getKey())){
						seenAlreadyFunction.put(entry2.getKey(), hashmap.get(entry2.getKey()));
					}
				}
				searchFlights(tmpSet, seenAlreadyFunction, entry.getKey(), totalCost, root);	
			}
		}
	}
	
	public static void outputResults(Queue<Queue<String>> possibleRoutes, String routeFrom){
		char prevDestination = ' ';
		int cost = 0;
		System.out.format("%-15s%-15s%-15s\n", "Destination", "From", "Price");
		for(Queue<String> listOfSets : possibleRoutes) {
			StringBuffer list = new StringBuffer("");
			for(String setValuesList : listOfSets){
				if(setValuesList.charAt(0) == routeFrom.charAt(0)){
					list.append(Character.toString(setValuesList.charAt(0)) + "," + Character.toString(setValuesList.charAt(1))); 
					cost = Integer.parseInt(setValuesList.substring(2, setValuesList.length()));
					prevDestination = setValuesList.charAt(1);
					System.out.format("%-15s%-15s%-15s\n", prevDestination, list, cost);
					}
				else if(prevDestination == setValuesList.charAt(0)){
					list.append("," + setValuesList.charAt(1));
					prevDestination = setValuesList.charAt(1);
					cost = Integer.parseInt(setValuesList.substring(2, setValuesList.length()));
					System.out.format("%-15s%-15s%-15s\n", prevDestination, list, cost);
				}
				else{
					while(prevDestination != setValuesList.charAt(0)){
						list.delete(list.length() - 2, list.length());
						prevDestination = list.charAt(list.length()-1);
					}
					list.append("," + setValuesList.charAt(1));
					prevDestination = setValuesList.charAt(1);
					cost = Integer.parseInt(setValuesList.substring(2, setValuesList.length()));
					System.out.format("%-15s%-15s%-15s\n", prevDestination, list, cost);	
				}
			}
		}	
	}
	
	public static void main(String [] args) {
		FileReader fr = null;
		BufferedReader br = null; 
		
		try {
			fr = new FileReader("input.txt");
			br = new BufferedReader(fr);
			
			//retrieve where you are leaving from
			String line = br.readLine();
			String routeFrom = line;
			
			//retrieve first line for destinations and costs
			line = br.readLine();	
			
			HashMap<String, Integer> map = new HashMap<>();
			while(line != null){
				String[] values = line.split(" ");				
				String key = values[0] + values[1];
				Integer value = Integer.parseInt(values[2]);
				map.put(key, value);				
				line = br.readLine();
			}		
			
			initiateSearch(map, routeFrom);
					
		} catch (FileNotFoundException fnfe) {
			System.out.println(fnfe.getMessage());
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		} finally {
			if( br != null) {
				try {
					br.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
			if( fr != null) {
				try {
					fr.close();
				} catch (IOException ioe) {
					System.out.println(ioe.getMessage());
				}
			}
		}
	}
}