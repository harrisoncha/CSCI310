import java.util.HashMap;
import java.util.Queue;
import java.util.Scanner;

public class SearchMap {
	
	public static void main(String [] args) {
		//retrieves your initial destination
		StringBuilder initialDestination = new StringBuilder ();
		//will store all possible routes and associated costs
		HashMap<String, Integer> map = new HashMap<>(); 
		
		//Retrieve file name
		Scanner in = new Scanner(System.in);
		System.out.print("Please enter the input file name: ");
		String inputFilename = in.nextLine();
		System.out.print("Please enter the output file name: ");
		String outputFilename = in.nextLine();
		in.close();
		
		//populate hashmap with data of flight routes
		map = FileReaderWriter.ReadFile(inputFilename, initialDestination);
		
		//start the search and retrieve results
		Queue<Queue<String>> possibleRoutes = FlightMap.initiateSearch(map, initialDestination);
		
		//output results to output file
		FileReaderWriter.WriteFile(possibleRoutes, initialDestination, outputFilename);
	}
	
}